import { pgTable, serial, integer, timestamp, unique } from "drizzle-orm/pg-core";
import { tracksTable } from "./tracks";
import { playlistsTable } from "./playlists";

export const playlistTracksTable = pgTable("playlist_tracks", {
  id: serial("id").primaryKey(),
  playlistId: integer("playlist_id").notNull().references(() => playlistsTable.id, { onDelete: "cascade" }),
  trackId: integer("track_id").notNull().references(() => tracksTable.id, { onDelete: "cascade" }),
  addedAt: timestamp("added_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [unique().on(t.playlistId, t.trackId)]);

export type PlaylistTrack = typeof playlistTracksTable.$inferSelect;
