import { Router, type IRouter } from "express";
import healthRouter from "./health";
import tracksRouter from "./tracks";
import playlistsRouter from "./playlists";
import spotifyRouter from "./spotify";
import textImportRouter from "./text-import";
import youtubeRouter from "./youtube";
import statsRouter from "./stats";

const router: IRouter = Router();

router.use(healthRouter);
router.use(tracksRouter);
router.use(playlistsRouter);
router.use(spotifyRouter);
router.use(textImportRouter);
router.use(youtubeRouter);
router.use(statsRouter);

export default router;
