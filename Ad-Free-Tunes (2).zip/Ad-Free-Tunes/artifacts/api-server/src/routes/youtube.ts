import { Router, type IRouter } from "express";
import axios from "axios";
import { SearchYoutubeQueryParams } from "@workspace/api-zod";
import { logger } from "../lib/logger";

const router: IRouter = Router();

function isoToMs(duration: string): number | null {
  const m = duration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!m) return null;
  const h = parseInt(m[1] ?? "0");
  const min = parseInt(m[2] ?? "0");
  const s = parseInt(m[3] ?? "0");
  return (h * 3600 + min * 60 + s) * 1000;
}

router.get("/youtube/search", async (req, res): Promise<void> => {
  const query = SearchYoutubeQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const apiKey = process.env.YOUTUBE_API_KEY;
  if (!apiKey) {
    res.status(500).json({ error: "YouTube API key not configured" });
    return;
  }

  try {
    const searchRes = await axios.get("https://www.googleapis.com/youtube/v3/search", {
      params: {
        part: "snippet",
        q: query.data.q,
        type: "video",
        maxResults: 5,
        key: apiKey,
      },
    });

    const items = searchRes.data.items as {
      id: { videoId: string };
      snippet: { title: string; channelTitle: string; thumbnails: { medium: { url: string } } };
    }[];

    if (!items || items.length === 0) {
      res.json([]);
      return;
    }

    const videoIds = items.map((i) => i.id.videoId).join(",");
    const detailsRes = await axios.get("https://www.googleapis.com/youtube/v3/videos", {
      params: { part: "contentDetails", id: videoIds, key: apiKey },
    });

    const durations: Record<string, number | null> = {};
    for (const v of detailsRes.data.items as { id: string; contentDetails: { duration: string } }[]) {
      durations[v.id] = isoToMs(v.contentDetails.duration);
    }

    const results = items.map((item) => ({
      videoId: item.id.videoId,
      title: item.snippet.title,
      channelTitle: item.snippet.channelTitle,
      thumbnailUrl: item.snippet.thumbnails.medium?.url ?? "",
      durationMs: durations[item.id.videoId] ?? null,
    }));

    res.json(results);
  } catch (err) {
    logger.error({ err }, "YouTube search failed");
    res.status(500).json({ error: "YouTube search failed" });
  }
});

export default router;
