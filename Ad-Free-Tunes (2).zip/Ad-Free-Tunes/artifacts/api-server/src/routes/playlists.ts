import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, tracksTable, playlistsTable, playlistTracksTable } from "@workspace/db";
import {
  GetPlaylistParams,
  UpdatePlaylistParams,
  UpdatePlaylistBody,
  DeletePlaylistParams,
  AddTrackToPlaylistParams,
  AddTrackToPlaylistBody,
  RemoveTrackFromPlaylistParams,
  CreatePlaylistBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/playlists", async (_req, res): Promise<void> => {
  const playlists = await db.select().from(playlistsTable).orderBy(playlistsTable.createdAt);
  res.json(playlists);
});

router.post("/playlists", async (req, res): Promise<void> => {
  const body = CreatePlaylistBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [playlist] = await db
    .insert(playlistsTable)
    .values({
      name: body.data.name,
      description: body.data.description ?? null,
      coverArt: body.data.coverArt ?? null,
    })
    .returning();
  res.status(201).json(playlist);
});

router.get("/playlists/:id", async (req, res): Promise<void> => {
  const params = GetPlaylistParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [playlist] = await db
    .select()
    .from(playlistsTable)
    .where(eq(playlistsTable.id, params.data.id));
  if (!playlist) {
    res.status(404).json({ error: "Playlist not found" });
    return;
  }
  const tracks = await db
    .select({ track: tracksTable })
    .from(playlistTracksTable)
    .innerJoin(tracksTable, eq(playlistTracksTable.trackId, tracksTable.id))
    .where(eq(playlistTracksTable.playlistId, params.data.id))
    .orderBy(playlistTracksTable.addedAt);
  res.json({ ...playlist, tracks: tracks.map((r) => r.track) });
});

router.patch("/playlists/:id", async (req, res): Promise<void> => {
  const params = UpdatePlaylistParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = UpdatePlaylistBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const updates: Record<string, unknown> = {};
  if (body.data.name !== undefined) updates.name = body.data.name;
  if (body.data.description !== undefined) updates.description = body.data.description;
  if (body.data.coverArt !== undefined) updates.coverArt = body.data.coverArt;

  const [playlist] = await db
    .update(playlistsTable)
    .set(updates)
    .where(eq(playlistsTable.id, params.data.id))
    .returning();
  if (!playlist) {
    res.status(404).json({ error: "Playlist not found" });
    return;
  }
  res.json(playlist);
});

router.delete("/playlists/:id", async (req, res): Promise<void> => {
  const params = DeletePlaylistParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [deleted] = await db
    .delete(playlistsTable)
    .where(eq(playlistsTable.id, params.data.id))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Playlist not found" });
    return;
  }
  res.sendStatus(204);
});

router.post("/playlists/:id/tracks", async (req, res): Promise<void> => {
  const params = AddTrackToPlaylistParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = AddTrackToPlaylistBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [track] = await db.select().from(tracksTable).where(eq(tracksTable.id, body.data.trackId));
  if (!track) {
    res.status(404).json({ error: "Track not found" });
    return;
  }
  await db
    .insert(playlistTracksTable)
    .values({ playlistId: params.data.id, trackId: body.data.trackId })
    .onConflictDoNothing();
  await db
    .update(playlistsTable)
    .set({ trackCount: sql`(SELECT COUNT(*) FROM playlist_tracks WHERE playlist_id = ${params.data.id})` })
    .where(eq(playlistsTable.id, params.data.id));
  res.status(201).json(track);
});

router.delete("/playlists/:id/tracks/:trackId", async (req, res): Promise<void> => {
  const params = RemoveTrackFromPlaylistParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  await db
    .delete(playlistTracksTable)
    .where(
      sql`playlist_id = ${params.data.id} AND track_id = ${params.data.trackId}`
    );
  await db
    .update(playlistsTable)
    .set({ trackCount: sql`(SELECT COUNT(*) FROM playlist_tracks WHERE playlist_id = ${params.data.id})` })
    .where(eq(playlistsTable.id, params.data.id));
  res.sendStatus(204);
});

export default router;
