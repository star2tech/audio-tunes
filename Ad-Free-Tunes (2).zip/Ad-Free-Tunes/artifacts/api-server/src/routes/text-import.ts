import { Router, type IRouter } from "express";
import axios from "axios";
import { db, tracksTable, playlistsTable, playlistTracksTable } from "@workspace/db";
import { ImportTextPlaylistBody } from "@workspace/api-zod";
import { logger } from "../lib/logger";
import { eq } from "drizzle-orm";

const router: IRouter = Router();

interface YTSearchItem {
  id: { videoId: string };
  snippet: {
    title: string;
    channelTitle: string;
    thumbnails: { medium?: { url: string }; default?: { url: string } };
  };
}

async function searchYouTube(query: string, apiKey: string): Promise<{ videoId: string; title: string; channelTitle: string; thumbnailUrl: string } | null> {
  try {
    const r = await axios.get("https://www.googleapis.com/youtube/v3/search", {
      params: { part: "snippet", q: query, type: "video", maxResults: 1, key: apiKey },
    });
    const items: YTSearchItem[] = r.data.items ?? [];
    if (!items.length) return null;
    const item = items[0];
    return {
      videoId: item.id.videoId,
      title: item.snippet.title,
      channelTitle: item.snippet.channelTitle,
      thumbnailUrl: item.snippet.thumbnails.medium?.url ?? item.snippet.thumbnails.default?.url ?? "",
    };
  } catch {
    return null;
  }
}

function parseSongLine(line: string): { title: string; artist: string } {
  const trimmed = line.trim();
  const dashIdx = trimmed.indexOf(" - ");
  if (dashIdx !== -1) {
    return { artist: trimmed.slice(0, dashIdx).trim(), title: trimmed.slice(dashIdx + 3).trim() };
  }
  return { artist: "", title: trimmed };
}

router.post("/import/text-playlist", async (req, res): Promise<void> => {
  const body = ImportTextPlaylistBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const apiKey = process.env.YOUTUBE_API_KEY;
  if (!apiKey) {
    res.status(500).json({ error: "YouTube API key not configured" });
    return;
  }

  const validSongs = body.data.songs.map((s) => s.trim()).filter(Boolean);
  if (!validSongs.length) {
    res.status(400).json({ error: "No valid songs provided" });
    return;
  }

  const [playlist] = await db
    .insert(playlistsTable)
    .values({ name: body.data.name })
    .returning();

  const insertedTracks: (typeof tracksTable.$inferSelect)[] = [];

  for (const songLine of validSongs) {
    const { title, artist } = parseSongLine(songLine);
    const searchQuery = artist ? `${artist} - ${title}` : title;

    const yt = await searchYouTube(searchQuery, apiKey);

    const [track] = await db
      .insert(tracksTable)
      .values({
        title,
        artist,
        albumName: "",
        albumArt: yt?.thumbnailUrl ?? null,
        durationMs: 0,
        youtubeVideoId: yt?.videoId ?? null,
      })
      .returning();

    if (track) {
      insertedTracks.push(track);
      await db
        .insert(playlistTracksTable)
        .values({ playlistId: playlist.id, trackId: track.id })
        .onConflictDoNothing();
    }
  }

  await db
    .update(playlistsTable)
    .set({ trackCount: insertedTracks.length })
    .where(eq(playlistsTable.id, playlist.id));

  res.status(201).json({ ...playlist, trackCount: insertedTracks.length, tracks: insertedTracks });
  logger.info({ playlistId: playlist.id, trackCount: insertedTracks.length }, "Text playlist imported");
});

export default router;
