import { Router, type IRouter } from "express";
import axios from "axios";
import { db, tracksTable, playlistsTable, playlistTracksTable } from "@workspace/db";
import { ImportSpotifyPlaylistBody } from "@workspace/api-zod";
import { logger } from "../lib/logger";
import { eq, sql } from "drizzle-orm";

const router: IRouter = Router();

let spotifyToken: string | null = null;
let tokenExpiry = 0;

async function getSpotifyToken(): Promise<string> {
  if (spotifyToken && Date.now() < tokenExpiry) return spotifyToken;

  const clientId = process.env.SPOTIFY_CLIENT_ID;
  const clientSecret = process.env.SPOTIFY_CLIENT_SECRET;

  if (!clientId || !clientSecret) {
    throw new Error("Spotify credentials not configured");
  }

  const creds = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
  const response = await axios.post(
    "https://accounts.spotify.com/api/token",
    "grant_type=client_credentials",
    {
      headers: {
        Authorization: `Basic ${creds}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
    }
  );

  spotifyToken = response.data.access_token;
  tokenExpiry = Date.now() + (response.data.expires_in - 60) * 1000;
  return spotifyToken!;
}

function extractPlaylistId(url: string): string | null {
  const patterns = [
    /spotify\.com\/playlist\/([a-zA-Z0-9]+)/,
    /spotify:playlist:([a-zA-Z0-9]+)/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}

router.post("/import/spotify-playlist", async (req, res): Promise<void> => {
  const body = ImportSpotifyPlaylistBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const playlistId = extractPlaylistId(body.data.url);
  if (!playlistId) {
    res.status(400).json({ error: "Invalid Spotify playlist URL" });
    return;
  }

  let token: string;
  try {
    token = await getSpotifyToken();
  } catch (err) {
    logger.error({ err }, "Failed to get Spotify token");
    res.status(422).json({ error: "Failed to authenticate with Spotify" });
    return;
  }

  const headers = { Authorization: `Bearer ${token}` };

  let spotifyPlaylist: Record<string, unknown>;
  try {
    const r = await axios.get(`https://api.spotify.com/v1/playlists/${playlistId}`, { headers });
    spotifyPlaylist = r.data;
  } catch (err: unknown) {
    logger.error({ err }, "Failed to fetch Spotify playlist");
    const status = (err as { response?: { status?: number } })?.response?.status;
    if (status === 403) {
      res.status(422).json({
        error:
          "Spotify denied access (403). Your Spotify app is in Development Mode — go to developer.spotify.com/dashboard → your app → Settings → User Management, and add your Spotify account email as a test user. Then try again.",
      });
    } else if (status === 404) {
      res.status(422).json({ error: "Playlist not found. Make sure the playlist is public and the URL is correct." });
    } else {
      res.status(422).json({ error: `Failed to fetch playlist from Spotify (status ${status ?? "unknown"})` });
    }
    return;
  }

  const playlistName = (spotifyPlaylist.name as string) || "Imported Playlist";
  const playlistDesc = (spotifyPlaylist.description as string) || null;
  const images = (spotifyPlaylist.images as { url: string }[]) || [];
  const coverArt = images[0]?.url ?? null;

  const [playlist] = await db
    .insert(playlistsTable)
    .values({
      name: playlistName,
      description: playlistDesc,
      coverArt,
      spotifyPlaylistId: playlistId,
    })
    .returning();

  const tracksObj = spotifyPlaylist.tracks as { items: unknown[]; next: string | null };
  let items = tracksObj.items || [];
  let nextUrl: string | null = tracksObj.next;

  while (nextUrl) {
    try {
      const r = await axios.get(nextUrl, { headers });
      items = items.concat(r.data.items);
      nextUrl = r.data.next;
    } catch {
      break;
    }
  }

  const insertedTracks: (typeof tracksTable.$inferSelect)[] = [];

  for (const item of items) {
    const t = (item as { track: Record<string, unknown> | null }).track;
    if (!t || t.type !== "track") continue;

    const artists = (t.artists as { name: string }[]).map((a) => a.name).join(", ");
    const album = t.album as { name: string; images: { url: string }[] };
    const albumArt = album.images?.[0]?.url ?? null;
    const durationMs = (t.duration_ms as number) || 0;
    const spotifyTrackId = t.id as string;

    const [track] = await db
      .insert(tracksTable)
      .values({
        title: (t.name as string) || "Unknown",
        artist: artists,
        albumName: album.name || "",
        albumArt,
        durationMs,
        spotifyTrackId,
      })
      .onConflictDoNothing()
      .returning();

    if (track) {
      insertedTracks.push(track);
      await db
        .insert(playlistTracksTable)
        .values({ playlistId: playlist.id, trackId: track.id })
        .onConflictDoNothing();
    }
  }

  await db
    .update(playlistsTable)
    .set({ trackCount: insertedTracks.length })
    .where(eq(playlistsTable.id, playlist.id));

  const finalPlaylist = { ...playlist, trackCount: insertedTracks.length };
  res.status(201).json({ ...finalPlaylist, tracks: insertedTracks });
});

export default router;
