import { Router, type IRouter } from "express";
import { db, tracksTable, playlistsTable } from "@workspace/db";
import { eq, count } from "drizzle-orm";

const router: IRouter = Router();

router.get("/stats", async (_req, res): Promise<void> => {
  const [totalTracksResult] = await db.select({ count: count() }).from(tracksTable);
  const [totalPlaylistsResult] = await db.select({ count: count() }).from(playlistsTable);
  const [likedTracksResult] = await db
    .select({ count: count() })
    .from(tracksTable)
    .where(eq(tracksTable.liked, true));

  res.json({
    totalTracks: Number(totalTracksResult?.count ?? 0),
    totalPlaylists: Number(totalPlaylistsResult?.count ?? 0),
    likedTracks: Number(likedTracksResult?.count ?? 0),
  });
});

export default router;
