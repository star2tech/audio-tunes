import { Router, type IRouter } from "express";
import { eq, ilike, or } from "drizzle-orm";
import { db, tracksTable } from "@workspace/db";
import {
  ListTracksQueryParams,
  GetTrackParams,
  ToggleLikedTrackParams,
  ToggleLikedTrackBody,
  SetTrackYoutubeIdParams,
  SetTrackYoutubeIdBody,
} from "@workspace/api-zod";
import { logger } from "../lib/logger";

const router: IRouter = Router();

router.get("/tracks", async (req, res): Promise<void> => {
  const query = ListTracksQueryParams.safeParse(req.query);
  let tracks;
  if (query.success && query.data.q) {
    const term = `%${query.data.q}%`;
    tracks = await db
      .select()
      .from(tracksTable)
      .where(or(ilike(tracksTable.title, term), ilike(tracksTable.artist, term)));
  } else {
    tracks = await db.select().from(tracksTable).orderBy(tracksTable.createdAt);
  }
  res.json(tracks);
});

router.get("/tracks/:id", async (req, res): Promise<void> => {
  const params = GetTrackParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [track] = await db.select().from(tracksTable).where(eq(tracksTable.id, params.data.id));
  if (!track) {
    res.status(404).json({ error: "Track not found" });
    return;
  }
  res.json(track);
});

router.patch("/tracks/:id/liked", async (req, res): Promise<void> => {
  const params = ToggleLikedTrackParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = ToggleLikedTrackBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [track] = await db
    .update(tracksTable)
    .set({ liked: body.data.liked })
    .where(eq(tracksTable.id, params.data.id))
    .returning();
  if (!track) {
    res.status(404).json({ error: "Track not found" });
    return;
  }
  res.json(track);
});

router.patch("/tracks/:id/youtube-id", async (req, res): Promise<void> => {
  const params = SetTrackYoutubeIdParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = SetTrackYoutubeIdBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [track] = await db
    .update(tracksTable)
    .set({ youtubeVideoId: body.data.youtubeVideoId })
    .where(eq(tracksTable.id, params.data.id))
    .returning();
  if (!track) {
    res.status(404).json({ error: "Track not found" });
    return;
  }
  res.json(track);
});

router.get("/liked-tracks", async (_req, res): Promise<void> => {
  const tracks = await db
    .select()
    .from(tracksTable)
    .where(eq(tracksTable.liked, true))
    .orderBy(tracksTable.createdAt);
  res.json(tracks);
});

export default router;
