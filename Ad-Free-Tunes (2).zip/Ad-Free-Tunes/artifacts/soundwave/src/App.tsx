import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { PlayerProvider } from "@/context/PlayerContext";
import { MainLayout } from "@/components/layout/MainLayout";

import Home from "@/pages/home";
import Search from "@/pages/search";
import Library from "@/pages/library";
import PlaylistDetail from "@/pages/playlist";
import LikedSongs from "@/pages/liked";
import Import from "@/pages/import";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <PlayerProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <MainLayout>
              <Switch>
                <Route path="/" component={Home} />
                <Route path="/search" component={Search} />
                <Route path="/library" component={Library} />
                <Route path="/playlist/:id" component={PlaylistDetail} />
                <Route path="/liked" component={LikedSongs} />
                <Route path="/import" component={Import} />
                <Route component={NotFound} />
              </Switch>
            </MainLayout>
          </WouterRouter>
          <Toaster />
          <SonnerToaster theme="dark" />
        </TooltipProvider>
      </PlayerProvider>
    </QueryClientProvider>
  );
}
