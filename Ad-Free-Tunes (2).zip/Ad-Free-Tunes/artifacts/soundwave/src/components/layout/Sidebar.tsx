import { Link, useLocation } from "wouter";
import { Home, Search, Library, PlusCircle, Heart, Download } from "lucide-react";
import { cn } from "@/lib/utils";

export function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    { icon: Home, label: "Home", href: "/" },
    { icon: Search, label: "Search", href: "/search" },
    { icon: Library, label: "Your Library", href: "/library" },
  ];

  const actionItems = [
    { icon: PlusCircle, label: "Create Playlist", href: "/library", onClick: () => {} }, // TODO: create playlist
    { icon: Heart, label: "Liked Songs", href: "/liked" },
    { icon: Download, label: "Import Spotify", href: "/import" },
  ];

  return (
    <div className="w-64 bg-sidebar border-r border-sidebar-border h-full flex flex-col px-4 py-6 text-sidebar-foreground">
      <div className="flex items-center gap-2 mb-8 px-2">
        <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="text-primary-foreground">
            <path d="M2 12h4l3-9 5 18 3-9h5" />
          </svg>
        </div>
        <span className="font-bold text-xl tracking-tight">Soundwave</span>
      </div>

      <div className="space-y-1 mb-8">
        {navItems.map((item) => {
          const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
          return (
            <Link key={item.label} href={item.href}>
              <div className={cn(
                "flex items-center gap-4 px-2 py-2.5 rounded-md transition-colors cursor-pointer group hover:text-foreground",
                isActive ? "text-primary font-medium" : "text-muted-foreground hover:bg-white/5"
              )}>
                <item.icon className={cn("w-5 h-5", isActive ? "text-primary" : "group-hover:text-foreground")} />
                {item.label}
              </div>
            </Link>
          );
        })}
      </div>

      <div className="space-y-1 mb-6">
        {actionItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.label} href={item.href}>
              <div className={cn(
                "flex items-center gap-4 px-2 py-2.5 rounded-md transition-colors cursor-pointer group hover:text-foreground",
                isActive ? "text-foreground font-medium bg-white/5" : "text-muted-foreground hover:bg-white/5"
              )}>
                <div className={cn(
                  "flex items-center justify-center rounded p-1",
                  item.label === "Liked Songs" ? "bg-gradient-to-br from-indigo-500 to-primary text-white" : "",
                  item.label === "Create Playlist" ? "bg-muted text-muted-foreground group-hover:bg-white group-hover:text-black" : "",
                  item.label === "Import Spotify" ? "bg-[#1DB954] text-white" : ""
                )}>
                  <item.icon className="w-4 h-4" />
                </div>
                {item.label}
              </div>
            </Link>
          );
        })}
      </div>

      <div className="mt-auto pt-6 border-t border-white/10">
         {/* Could list individual playlists here */}
      </div>
    </div>
  );
}
