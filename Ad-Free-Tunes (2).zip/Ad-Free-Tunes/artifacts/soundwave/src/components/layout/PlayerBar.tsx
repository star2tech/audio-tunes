import { usePlayer } from "@/context/PlayerContext";
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Heart, Youtube } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { useToggleLikedTrack, getGetLikedTracksQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

function formatTime(seconds: number) {
  if (!seconds || isNaN(seconds)) return "0:00";
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, "0")}`;
}

export function PlayerBar() {
  const { 
    currentTrack, 
    isPlaying, 
    volume, 
    progress, 
    duration, 
    togglePlay, 
    nextTrack, 
    prevTrack, 
    setVolumeLevel,
    seekTo 
  } = usePlayer();

  const queryClient = useQueryClient();
  const toggleLike = useToggleLikedTrack();

  const handleLike = () => {
    if (!currentTrack) return;
    toggleLike.mutate({
      id: currentTrack.id,
      data: { liked: !currentTrack.liked }
    }, {
      onSuccess: () => {
        // Ideally invalidate track query here
        queryClient.invalidateQueries({ queryKey: getGetLikedTracksQueryKey() });
      }
    });
  };

  if (!currentTrack) {
    return (
      <div className="h-24 bg-card border-t border-border flex items-center justify-between px-6 text-muted-foreground z-50 relative">
        <div className="flex-1"></div>
        <div className="flex-1 flex justify-center text-sm">Select a track to play</div>
        <div className="flex-1"></div>
      </div>
    );
  }

  return (
    <div className="h-24 bg-card border-t border-border flex items-center justify-between px-6 z-50 relative">
      <div className="flex-1 flex items-center gap-4 min-w-0">
        <div className="w-14 h-14 bg-muted rounded overflow-hidden flex-shrink-0 relative">
          {currentTrack.albumArt ? (
            <img src={currentTrack.albumArt} alt={currentTrack.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-secondary flex items-center justify-center">
              <Youtube className="w-6 h-6 text-muted-foreground" />
            </div>
          )}
        </div>
        <div className="min-w-0 truncate pr-4">
          <div className="font-medium text-foreground truncate hover:underline cursor-pointer">{currentTrack.title}</div>
          <div className="text-sm text-muted-foreground truncate hover:underline cursor-pointer">{currentTrack.artist}</div>
        </div>
        <button onClick={handleLike} className="text-muted-foreground hover:text-foreground transition flex-shrink-0">
          <Heart className={`w-5 h-5 ${currentTrack.liked ? 'fill-primary text-primary' : ''}`} />
        </button>
      </div>

      <div className="flex-1 max-w-2xl flex flex-col items-center gap-2">
        <div className="flex items-center gap-6">
          <button onClick={prevTrack} className="text-muted-foreground hover:text-foreground transition">
            <SkipBack className="w-5 h-5" />
          </button>
          
          <button 
            onClick={togglePlay} 
            className="w-10 h-10 rounded-full bg-foreground text-background flex items-center justify-center hover:scale-105 transition"
          >
            {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-1" />}
          </button>
          
          <button onClick={nextTrack} className="text-muted-foreground hover:text-foreground transition">
            <SkipForward className="w-5 h-5" />
          </button>
        </div>

        <div className="w-full flex items-center gap-3 text-xs text-muted-foreground">
          <span className="w-10 text-right">{formatTime(progress)}</span>
          <Slider 
            value={[progress]} 
            max={duration || 100} 
            step={1} 
            onValueChange={([val]) => seekTo(val)}
            className="flex-1"
          />
          <span className="w-10 text-left">{formatTime(duration)}</span>
        </div>
      </div>

      <div className="flex-1 flex justify-end items-center gap-3 min-w-0">
        {!currentTrack.youtubeVideoId && (
           <span className="text-xs text-primary animate-pulse mr-4 whitespace-nowrap">Finding on YouTube...</span>
        )}
        <button onClick={() => setVolumeLevel(volume === 0 ? 50 : 0)} className="text-muted-foreground hover:text-foreground transition">
          {volume === 0 ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
        </button>
        <div className="w-24">
          <Slider 
            value={[volume]} 
            max={100} 
            step={1} 
            onValueChange={([val]) => setVolumeLevel(val)}
          />
        </div>
      </div>
    </div>
  );
}
