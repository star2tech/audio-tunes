import { Sidebar } from "./Sidebar";
import { PlayerBar } from "./PlayerBar";

export function MainLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="h-screen w-full bg-background flex flex-col overflow-hidden text-foreground">
      <div className="flex-1 flex overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-y-auto bg-gradient-to-b from-card to-background">
          <div className="min-h-full pb-24">
            {children}
          </div>
        </main>
      </div>
      <PlayerBar />
    </div>
  );
}
