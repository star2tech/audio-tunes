import { useState, useEffect } from "react";
import { Track } from "@workspace/api-client-react";
import { 
  useToggleLikedTrack, 
  getGetLikedTracksQueryKey, 
  useSearchYoutube, 
  getSearchYoutubeQueryKey,
  useSetTrackYoutubeId,
  getListTracksQueryKey,
  getGetPlaylistQueryKey
} from "@workspace/api-client-react";
import { Play, Heart, Loader2 } from "lucide-react";
import { usePlayer } from "@/context/PlayerContext";
import { useQueryClient } from "@tanstack/react-query";

interface TrackRowProps {
  track: Track;
  index: number;
  queue: Track[];
  playlistId?: number; // to invalidate if needed
}

export function TrackRow({ track, index, queue, playlistId }: TrackRowProps) {
  const { playTrack, currentTrack, isPlaying } = usePlayer();
  const toggleLike = useToggleLikedTrack();
  const setYoutubeId = useSetTrackYoutubeId();
  const queryClient = useQueryClient();
  
  const [isSearching, setIsSearching] = useState(false);
  const isCurrent = currentTrack?.id === track.id;

  // Auto-search youtube video if missing and it becomes current track, or just proactively search?
  // "When a track has no youtubeVideoId yet, auto-trigger useSearchYoutube with "{artist} {title}" query and call useSetTrackYoutubeId with the top result automatically. Show a small spinner on the track row while this happens."
  // We can proactively search for it when rendered, or when clicked. If we search on render, it might cause too many API calls. We'll only search when it is the currentTrack but has no ID, OR if we want to do it aggressively. The prompt says "When a track has no youtubeVideoId yet, auto-trigger..." Let's do it when it renders, but to avoid spamming, maybe we do it if it's in viewport or just right away.
  // Actually, we can just do it in a useEffect if !track.youtubeVideoId
  
  const searchQuery = { q: `${track.artist} ${track.title}` };
  const { refetch: searchYoutube } = useSearchYoutube(
    searchQuery,
    { query: { enabled: false, queryKey: getSearchYoutubeQueryKey(searchQuery) } }
  );

  useEffect(() => {
    let mounted = true;
    
    async function doSearch() {
      if (track.youtubeVideoId || isSearching) return;
      
      setIsSearching(true);
      try {
        const { data: results } = await searchYoutube();
        if (mounted && results && results.length > 0) {
          const topResult = results[0];
          await setYoutubeId.mutateAsync({
            id: track.id,
            data: { youtubeVideoId: topResult.videoId }
          });
          
          // Invalidate everywhere this track might be
          queryClient.invalidateQueries({ queryKey: getGetLikedTracksQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListTracksQueryKey() });
          if (playlistId) {
            queryClient.invalidateQueries({ queryKey: getGetPlaylistQueryKey(playlistId) });
          }
        }
      } catch (err) {
        console.error("Failed to search youtube", err);
      } finally {
        if (mounted) setIsSearching(false);
      }
    }

    // Only search if it really doesn't have an ID
    if (!track.youtubeVideoId) {
      doSearch();
    }

    return () => { mounted = false; };
  }, [track.id, track.youtubeVideoId, track.artist, track.title]); // exclude other deps to run once

  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleLike.mutate({
      id: track.id,
      data: { liked: !track.liked }
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetLikedTracksQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListTracksQueryKey() });
        if (playlistId) {
          queryClient.invalidateQueries({ queryKey: getGetPlaylistQueryKey(playlistId) });
        }
      }
    });
  };

  return (
    <div 
      className={`flex items-center px-4 py-3 rounded-md group hover:bg-white/5 transition-colors cursor-pointer ${isCurrent ? 'bg-white/5' : ''}`}
      onClick={() => playTrack(track, queue)}
    >
      <div className="w-12 text-center text-muted-foreground relative flex items-center justify-center">
        {isSearching && !isCurrent ? (
          <Loader2 className="w-4 h-4 animate-spin text-primary" />
        ) : (
          <>
            <span className="group-hover:opacity-0 block">{index + 1}</span>
            <button className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <Play className="w-4 h-4 fill-current text-white" />
            </button>
          </>
        )}
      </div>
      
      <div className="flex-1 flex items-center gap-4 min-w-0 pr-4">
        <div className="w-10 h-10 bg-secondary rounded overflow-hidden flex-shrink-0">
          {track.albumArt && <img src={track.albumArt} alt={track.title} className="w-full h-full object-cover" />}
        </div>
        <div className="min-w-0">
          <div className={`font-medium truncate ${isCurrent ? 'text-primary' : 'text-white'}`}>{track.title}</div>
          <div className="text-sm text-muted-foreground truncate">{track.artist}</div>
        </div>
      </div>
      
      <div className="flex-1 hidden md:block text-sm text-muted-foreground truncate pr-4">
        {track.albumName}
      </div>
      
      <div className="w-24 text-right flex items-center justify-end gap-4 pr-4">
        <button 
          onClick={handleLike}
          className="opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <Heart className={`w-5 h-5 ${track.liked ? 'fill-primary text-primary opacity-100' : 'text-muted-foreground hover:text-white'}`} />
        </button>
        <span className="text-sm text-muted-foreground font-variant-numeric tabular-nums">
          {Math.floor(track.durationMs / 60000)}:{(Math.floor((track.durationMs % 60000) / 1000)).toString().padStart(2, '0')}
        </span>
      </div>
    </div>
  );
}
