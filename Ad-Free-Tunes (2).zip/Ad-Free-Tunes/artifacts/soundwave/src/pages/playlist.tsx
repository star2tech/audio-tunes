import { useRoute } from "wouter";
import { 
  useGetPlaylist, 
  getGetPlaylistQueryKey, 
  useDeletePlaylist, 
  getListPlaylistsQueryKey,
  useUpdatePlaylist
} from "@workspace/api-client-react";
import { Play, Music, MoreHorizontal, Trash, Edit2 } from "lucide-react";
import { TrackRow } from "@/components/TrackRow";
import { usePlayer } from "@/context/PlayerContext";
import { Skeleton } from "@/components/ui/skeleton";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function PlaylistDetail() {
  const [match, params] = useRoute("/playlist/:id");
  const id = params?.id ? parseInt(params.id) : 0;
  const [, setLocation] = useLocation();

  const { data: playlist, isLoading } = useGetPlaylist(id, {
    query: { enabled: !!id, queryKey: getGetPlaylistQueryKey(id) }
  });

  const { playTrack } = usePlayer();
  const deletePlaylist = useDeletePlaylist();
  const queryClient = useQueryClient();

  if (!match) return null;

  const handlePlayAll = () => {
    if (playlist && playlist.tracks.length > 0) {
      playTrack(playlist.tracks[0], playlist.tracks);
    }
  };

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this playlist?")) {
      deletePlaylist.mutate({ id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListPlaylistsQueryKey() });
          setLocation("/library");
        }
      });
    }
  };

  if (isLoading) {
    return (
      <div className="p-8 max-w-7xl mx-auto">
        <div className="flex gap-6 mb-8 items-end">
          <Skeleton className="w-52 h-52 bg-card rounded-md shadow-2xl" />
          <div className="space-y-4 flex-1">
            <Skeleton className="w-24 h-4 bg-card" />
            <Skeleton className="w-2/3 h-12 bg-card" />
            <Skeleton className="w-1/3 h-4 bg-card" />
          </div>
        </div>
      </div>
    );
  }

  if (!playlist) return <div className="p-8 text-center text-muted-foreground">Playlist not found</div>;

  return (
    <div className="pb-8">
      {/* Header */}
      <div className="bg-gradient-to-b from-card/80 to-background p-8 pt-12 flex flex-col md:flex-row gap-6 md:items-end">
        <div className="w-52 h-52 bg-secondary rounded-md overflow-hidden shadow-2xl flex-shrink-0 relative">
          {playlist.coverArt ? (
            <img src={playlist.coverArt} alt={playlist.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-muted-foreground">
              <Music className="w-20 h-20 opacity-50" />
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-2">Playlist</p>
          <h1 className="text-4xl md:text-6xl font-black text-white mb-4 tracking-tight truncate">{playlist.name}</h1>
          <p className="text-muted-foreground mb-2">{playlist.description}</p>
          <p className="text-sm font-medium text-white/80">
            Soundwave • {playlist.trackCount} songs
          </p>
        </div>
      </div>

      {/* Controls */}
      <div className="px-8 py-6 flex items-center gap-6">
        <button 
          onClick={handlePlayAll}
          className="w-14 h-14 bg-primary text-primary-foreground rounded-full flex items-center justify-center hover:scale-105 transition-transform shadow-xl"
        >
          <Play className="w-7 h-7 fill-current ml-1" />
        </button>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="text-muted-foreground hover:text-white transition">
              <MoreHorizontal className="w-8 h-8" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-48 bg-card border-card-border">
            <DropdownMenuItem className="text-destructive focus:text-destructive focus:bg-destructive/10 cursor-pointer" onClick={handleDelete}>
              <Trash className="mr-2 h-4 w-4" />
              <span>Delete Playlist</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Track List */}
      <div className="px-8 max-w-7xl mx-auto">
        {playlist.tracks.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            <Music className="w-12 h-12 mx-auto mb-4 opacity-20" />
            <p className="text-lg">This playlist is empty</p>
            <p className="text-sm">Search for songs to add them here.</p>
          </div>
        ) : (
          <div className="space-y-1">
            <div className="flex items-center px-4 py-2 text-sm text-muted-foreground font-medium border-b border-border/50 mb-4">
              <div className="w-12 text-center">#</div>
              <div className="flex-1">Title</div>
              <div className="flex-1 hidden md:block">Album</div>
              <div className="w-24 text-right pr-8">Time</div>
            </div>
            
            {playlist.tracks.map((track, i) => (
              <TrackRow 
                key={track.id} 
                track={track} 
                index={i} 
                queue={playlist.tracks} 
                playlistId={playlist.id} 
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
