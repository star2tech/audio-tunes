import { useState } from "react";
import { useImportTextPlaylist, getListPlaylistsQueryKey } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { Music2, Loader2, ListMusic, Plus, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export default function Import() {
  const [playlistName, setPlaylistName] = useState("");
  const [songsText, setSongsText] = useState("");
  const [_, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const importPlaylist = useImportTextPlaylist();

  const songLines = songsText
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);

  const handleImport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!playlistName.trim()) {
      toast.error("Please enter a playlist name");
      return;
    }
    if (!songLines.length) {
      toast.error("Please add at least one song");
      return;
    }

    try {
      const result = await importPlaylist.mutateAsync({
        data: { name: playlistName.trim(), songs: songLines },
      });
      toast.success(`Playlist created with ${result.tracks?.length ?? 0} tracks!`);
      queryClient.invalidateQueries({ queryKey: getListPlaylistsQueryKey() });
      setLocation(`/playlist/${result.id}`);
    } catch (err: unknown) {
      const msg = (err as { data?: { error?: string }; message?: string })?.data?.error ?? (err as { message?: string })?.message ?? "Failed to create playlist";
      toast.error(msg);
    }
  };

  const handleExampleFill = () => {
    setSongsText(
      "The Weeknd - Blinding Lights\nDua Lipa - Levitating\nHarry Styles - As It Was\nOlivia Rodrigo - drivers license\nBillie Eilish - bad guy"
    );
    if (!playlistName) setPlaylistName("My Playlist");
  };

  return (
    <div className="p-8 max-w-2xl mx-auto min-h-[80vh] flex flex-col justify-center">
      <div className="bg-card border border-card-border rounded-2xl p-10 shadow-2xl relative overflow-hidden">
        {/* Background glow */}
        <div className="absolute top-0 right-0 w-72 h-72 bg-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-primary/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/4 pointer-events-none" />

        <div className="flex items-center gap-4 mb-2 relative z-10">
          <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
            <ListMusic className="w-6 h-6 text-primary" />
          </div>
          <h1 className="text-3xl font-bold text-white tracking-tight">Create Playlist</h1>
        </div>

        <p className="text-muted-foreground mb-8 relative z-10 text-sm leading-relaxed">
          Paste your songs below — one per line. Use <span className="text-white font-medium">Artist - Song Title</span> format for best results.
          We'll find each track on YouTube automatically.
        </p>

        <form onSubmit={handleImport} className="space-y-5 relative z-10">
          <div>
            <label className="block text-sm font-medium text-white mb-2">
              Playlist Name
            </label>
            <Input
              type="text"
              placeholder="My Awesome Playlist"
              value={playlistName}
              onChange={(e) => setPlaylistName(e.target.value)}
              className="bg-background border-border h-11"
              data-testid="input-playlist-name"
              required
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-white">
                Songs{songLines.length > 0 && (
                  <span className="ml-2 text-primary text-xs font-normal">{songLines.length} song{songLines.length !== 1 ? "s" : ""}</span>
                )}
              </label>
              <button
                type="button"
                onClick={handleExampleFill}
                className="text-xs text-muted-foreground hover:text-primary transition-colors"
                data-testid="button-example-fill"
              >
                Fill example
              </button>
            </div>
            <Textarea
              placeholder={"The Weeknd - Blinding Lights\nDua Lipa - Levitating\nHarry Styles - As It Was\n..."}
              value={songsText}
              onChange={(e) => setSongsText(e.target.value)}
              className="bg-background border-border min-h-[200px] font-mono text-sm resize-none"
              data-testid="textarea-songs"
            />
            <p className="text-xs text-muted-foreground mt-2">
              One song per line. Format: <code className="text-primary">Artist - Title</code> or just <code className="text-primary">Song Title</code>
            </p>
          </div>

          {/* Preview of parsed songs */}
          {songLines.length > 0 && (
            <div className="bg-background/50 border border-border rounded-xl p-4 max-h-48 overflow-y-auto">
              <p className="text-xs font-medium text-muted-foreground mb-3 uppercase tracking-widest">Preview</p>
              <div className="space-y-1.5">
                {songLines.slice(0, 20).map((line, i) => {
                  const dashIdx = line.indexOf(" - ");
                  const artist = dashIdx !== -1 ? line.slice(0, dashIdx) : null;
                  const title = dashIdx !== -1 ? line.slice(dashIdx + 3) : line;
                  return (
                    <div key={i} className="flex items-center gap-3" data-testid={`preview-song-${i}`}>
                      <span className="text-xs text-muted-foreground w-5 text-right shrink-0">{i + 1}</span>
                      <Music2 className="w-3 h-3 text-primary shrink-0" />
                      <span className="text-sm text-white truncate">
                        {artist && <span className="text-muted-foreground">{artist} — </span>}
                        {title}
                      </span>
                    </div>
                  );
                })}
                {songLines.length > 20 && (
                  <p className="text-xs text-muted-foreground text-center pt-1">
                    +{songLines.length - 20} more
                  </p>
                )}
              </div>
            </div>
          )}

          <Button
            type="submit"
            disabled={importPlaylist.isPending || !playlistName.trim() || !songLines.length}
            className="w-full h-12 text-base font-semibold"
            data-testid="button-create-playlist"
          >
            {importPlaylist.isPending ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Finding tracks on YouTube… ({songLines.length} songs)
              </>
            ) : (
              <>
                <Plus className="mr-2 h-5 w-5" />
                Create Playlist
              </>
            )}
          </Button>
        </form>
      </div>
    </div>
  );
}
