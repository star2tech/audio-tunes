import { useGetLikedTracks, getGetLikedTracksQueryKey } from "@workspace/api-client-react";
import { Play, Heart } from "lucide-react";
import { TrackRow } from "@/components/TrackRow";
import { usePlayer } from "@/context/PlayerContext";
import { Skeleton } from "@/components/ui/skeleton";

export default function LikedSongs() {
  const { data: tracks, isLoading } = useGetLikedTracks({
    query: { queryKey: getGetLikedTracksQueryKey() }
  });

  const { playTrack } = usePlayer();

  const handlePlayAll = () => {
    if (tracks && tracks.length > 0) {
      playTrack(tracks[0], tracks);
    }
  };

  if (isLoading) {
    return (
      <div className="p-8 max-w-7xl mx-auto">
        <div className="flex gap-6 mb-8 items-end">
          <Skeleton className="w-52 h-52 bg-card rounded-md shadow-2xl" />
          <div className="space-y-4 flex-1">
            <Skeleton className="w-24 h-4 bg-card" />
            <Skeleton className="w-2/3 h-12 bg-card" />
            <Skeleton className="w-1/3 h-4 bg-card" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-8">
      {/* Header */}
      <div className="bg-gradient-to-b from-indigo-900/40 via-card/80 to-background p-8 pt-12 flex flex-col md:flex-row gap-6 md:items-end">
        <div className="w-52 h-52 bg-gradient-to-br from-indigo-500 to-primary rounded-md shadow-2xl flex items-center justify-center flex-shrink-0">
          <Heart className="w-20 h-20 text-white fill-white" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold uppercase tracking-wider text-white/80 mb-2">Playlist</p>
          <h1 className="text-4xl md:text-6xl font-black text-white mb-4 tracking-tight truncate">Liked Songs</h1>
          <p className="text-sm font-medium text-white/80">
            {tracks?.length || 0} songs
          </p>
        </div>
      </div>

      {/* Controls */}
      <div className="px-8 py-6 flex items-center gap-6">
        <button 
          onClick={handlePlayAll}
          disabled={!tracks || tracks.length === 0}
          className="w-14 h-14 bg-primary text-primary-foreground rounded-full flex items-center justify-center hover:scale-105 transition-transform shadow-xl disabled:opacity-50 disabled:hover:scale-100"
        >
          <Play className="w-7 h-7 fill-current ml-1" />
        </button>
      </div>

      {/* Track List */}
      <div className="px-8 max-w-7xl mx-auto">
        {!tracks || tracks.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            <Heart className="w-12 h-12 mx-auto mb-4 opacity-20" />
            <p className="text-lg">Songs you like will appear here</p>
            <p className="text-sm">Save songs by tapping the heart icon.</p>
          </div>
        ) : (
          <div className="space-y-1">
            <div className="flex items-center px-4 py-2 text-sm text-muted-foreground font-medium border-b border-border/50 mb-4">
              <div className="w-12 text-center">#</div>
              <div className="flex-1">Title</div>
              <div className="flex-1 hidden md:block">Album</div>
              <div className="w-24 text-right pr-8">Time</div>
            </div>
            
            {tracks.map((track, i) => (
              <TrackRow 
                key={track.id} 
                track={track} 
                index={i} 
                queue={tracks} 
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
