import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Search as SearchIcon, Play, Heart, Plus } from "lucide-react";
import { useListTracks, getListTracksQueryKey, useToggleLikedTrack, getGetLikedTracksQueryKey } from "@workspace/api-client-react";
import { usePlayer } from "@/context/PlayerContext";
import { useQueryClient } from "@tanstack/react-query";
import { useDebounce } from "@/hooks/use-debounce"; // Assuming we will create a simple useDebounce

export default function Search() {
  const [query, setQuery] = useState("");
  const debouncedQuery = query; // Replace with useDebounce(query, 300) when implemented

  const { data: tracks, isLoading } = useListTracks(
    debouncedQuery ? { q: debouncedQuery } : undefined,
    { query: { enabled: true, queryKey: getListTracksQueryKey(debouncedQuery ? { q: debouncedQuery } : undefined) } }
  );

  const { playTrack, currentTrack, isPlaying } = usePlayer();
  const toggleLike = useToggleLikedTrack();
  const queryClient = useQueryClient();

  const handleLike = (e: React.MouseEvent, trackId: number, currentLiked: boolean) => {
    e.stopPropagation();
    toggleLike.mutate({
      id: trackId,
      data: { liked: !currentLiked }
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListTracksQueryKey(debouncedQuery ? { q: debouncedQuery } : undefined) });
        queryClient.invalidateQueries({ queryKey: getGetLikedTracksQueryKey() });
      }
    });
  };

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="max-w-xl mb-10">
        <div className="relative">
          <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-6 h-6 text-muted-foreground" />
          <Input 
            type="text"
            placeholder="What do you want to listen to?" 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full h-14 pl-14 pr-4 bg-white/10 border-transparent focus:bg-white/15 focus:border-transparent rounded-full text-lg placeholder:text-muted-foreground shadow-lg"
          />
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-2 mt-8">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-16 bg-card rounded-md animate-pulse"></div>
          ))}
        </div>
      ) : query && tracks && tracks.length === 0 ? (
        <div className="text-center py-20 text-muted-foreground">
          <p className="text-xl font-medium mb-2">No results found for "{query}"</p>
          <p>Please make sure your words are spelled correctly or use less or different keywords.</p>
        </div>
      ) : tracks && tracks.length > 0 ? (
        <div className="space-y-1">
          {/* Track headers */}
          <div className="flex items-center px-4 py-2 text-sm text-muted-foreground font-medium border-b border-border/50 mb-4">
            <div className="w-12 text-center">#</div>
            <div className="flex-1">Title</div>
            <div className="flex-1 hidden md:block">Album</div>
            <div className="w-24 text-right pr-8">Time</div>
          </div>

          {tracks.map((track, i) => {
            const isCurrent = currentTrack?.id === track.id;
            return (
              <div 
                key={track.id}
                className={`flex items-center px-4 py-3 rounded-md group hover:bg-white/5 transition-colors cursor-pointer ${isCurrent ? 'bg-white/5' : ''}`}
                onClick={() => playTrack(track, tracks)}
              >
                <div className="w-12 text-center text-muted-foreground relative">
                  <span className="group-hover:opacity-0 block">{i + 1}</span>
                  <button className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="w-4 h-4 fill-current text-white" />
                  </button>
                </div>
                
                <div className="flex-1 flex items-center gap-4 min-w-0 pr-4">
                  <div className="w-10 h-10 bg-secondary rounded overflow-hidden flex-shrink-0">
                    {track.albumArt && <img src={track.albumArt} alt={track.title} className="w-full h-full object-cover" />}
                  </div>
                  <div className="min-w-0">
                    <div className={`font-medium truncate ${isCurrent ? 'text-primary' : 'text-white'}`}>{track.title}</div>
                    <div className="text-sm text-muted-foreground truncate">{track.artist}</div>
                  </div>
                </div>
                
                <div className="flex-1 hidden md:block text-sm text-muted-foreground truncate pr-4">
                  {track.albumName}
                </div>
                
                <div className="w-24 text-right flex items-center justify-end gap-4 pr-4">
                  <button 
                    onClick={(e) => handleLike(e, track.id, track.liked)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Heart className={`w-5 h-5 ${track.liked ? 'fill-primary text-primary opacity-100' : 'text-muted-foreground hover:text-white'}`} />
                  </button>
                  <span className="text-sm text-muted-foreground font-variant-numeric tabular-nums">
                    {Math.floor(track.durationMs / 60000)}:{(Math.floor((track.durationMs % 60000) / 1000)).toString().padStart(2, '0')}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      ) : null}
    </div>
  );
}
