import { useListPlaylists, getListPlaylistsQueryKey, useCreatePlaylist } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Plus, Music } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useQueryClient } from "@tanstack/react-query";

export default function Library() {
  const { data: playlists, isLoading } = useListPlaylists({
    query: { queryKey: getListPlaylistsQueryKey() }
  });

  const createPlaylist = useCreatePlaylist();
  const queryClient = useQueryClient();

  const handleCreate = () => {
    createPlaylist.mutate({
      data: { name: `My Playlist #${(playlists?.length || 0) + 1}` }
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListPlaylistsQueryKey() });
      }
    });
  };

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-4xl font-bold text-white tracking-tight">Your Library</h1>
        <button 
          onClick={handleCreate}
          disabled={createPlaylist.isPending}
          className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-full font-medium transition-colors disabled:opacity-50"
        >
          <Plus className="w-5 h-5" />
          Create Playlist
        </button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} className="space-y-4">
              <Skeleton className="aspect-square rounded-md bg-card" />
              <Skeleton className="h-4 w-3/4 bg-card" />
              <Skeleton className="h-3 w-1/2 bg-card" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
          <Link href="/liked">
            <div className="bg-gradient-to-br from-indigo-500 via-purple-500 to-primary p-6 rounded-xl border border-transparent hover:scale-[1.02] transition-all cursor-pointer h-full flex flex-col justify-end shadow-lg aspect-square">
              <h3 className="font-bold text-3xl text-white mb-2">Liked Songs</h3>
              <p className="text-white/80 font-medium">Your favorite tracks</p>
            </div>
          </Link>

          {playlists?.map(playlist => (
            <Link key={playlist.id} href={`/playlist/${playlist.id}`}>
              <div className="bg-card p-4 rounded-xl border border-card-border hover:bg-white/5 transition-all cursor-pointer group h-full">
                <div className="aspect-square bg-secondary rounded-md mb-4 overflow-hidden shadow-lg relative">
                  {playlist.coverArt ? (
                    <img src={playlist.coverArt} alt={playlist.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-muted-foreground group-hover:scale-105 transition-transform duration-500">
                      <Music className="w-12 h-12 opacity-50" />
                    </div>
                  )}
                </div>
                <h3 className="font-bold text-white truncate mb-1">{playlist.name}</h3>
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {playlist.description || `${playlist.trackCount} tracks`}
                </p>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
