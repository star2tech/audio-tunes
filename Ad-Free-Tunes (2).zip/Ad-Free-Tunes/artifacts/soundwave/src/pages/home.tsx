import { useGetStats, getGetStatsQueryKey, useListPlaylists, getListPlaylistsQueryKey } from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Music, ListMusic, Heart, Play } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { data: stats, isLoading: statsLoading } = useGetStats({
    query: { queryKey: getGetStatsQueryKey() }
  });

  const { data: playlists, isLoading: playlistsLoading } = useListPlaylists({
    query: { queryKey: getListPlaylistsQueryKey() }
  });

  const recentPlaylists = playlists?.slice(0, 6) || [];

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <h1 className="text-4xl font-bold mb-8 text-white tracking-tight">Good evening</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        {statsLoading ? (
          <>
            <Skeleton className="h-32 rounded-xl bg-card border-card-border" />
            <Skeleton className="h-32 rounded-xl bg-card border-card-border" />
            <Skeleton className="h-32 rounded-xl bg-card border-card-border" />
          </>
        ) : (
          <>
            <Card className="p-6 bg-card border-card-border flex items-center gap-6 hover:bg-white/5 transition-colors cursor-pointer group">
              <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                <Music className="w-7 h-7" />
              </div>
              <div>
                <div className="text-3xl font-bold text-white mb-1">{stats?.totalTracks || 0}</div>
                <div className="text-muted-foreground font-medium">Total Tracks</div>
              </div>
            </Card>

            <Link href="/library">
              <Card className="p-6 bg-card border-card-border flex items-center gap-6 hover:bg-white/5 transition-colors cursor-pointer group">
                <div className="w-14 h-14 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform">
                  <ListMusic className="w-7 h-7" />
                </div>
                <div>
                  <div className="text-3xl font-bold text-white mb-1">{stats?.totalPlaylists || 0}</div>
                  <div className="text-muted-foreground font-medium">Playlists</div>
                </div>
              </Card>
            </Link>

            <Link href="/liked">
              <Card className="p-6 bg-card border-card-border flex items-center gap-6 hover:bg-white/5 transition-colors cursor-pointer group">
                <div className="w-14 h-14 rounded-full bg-pink-500/20 flex items-center justify-center text-pink-400 group-hover:scale-110 transition-transform">
                  <Heart className="w-7 h-7" />
                </div>
                <div>
                  <div className="text-3xl font-bold text-white mb-1">{stats?.likedTracks || 0}</div>
                  <div className="text-muted-foreground font-medium">Liked Songs</div>
                </div>
              </Card>
            </Link>
          </>
        )}
      </div>

      <h2 className="text-2xl font-bold mb-6 text-white">Recently added</h2>
      
      {playlistsLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="space-y-4">
              <Skeleton className="aspect-square rounded-md bg-card" />
              <Skeleton className="h-4 w-3/4 bg-card" />
              <Skeleton className="h-3 w-1/2 bg-card" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {recentPlaylists.map(playlist => (
            <Link key={playlist.id} href={`/playlist/${playlist.id}`}>
              <div className="bg-card p-4 rounded-xl border border-card-border hover:bg-white/5 transition-all cursor-pointer group">
                <div className="aspect-square bg-secondary rounded-md mb-4 overflow-hidden relative shadow-lg">
                  {playlist.coverArt ? (
                    <img src={playlist.coverArt} alt={playlist.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-muted-foreground group-hover:scale-105 transition-transform duration-500">
                      <Music className="w-12 h-12 opacity-50" />
                    </div>
                  )}
                  
                  {/* Play button overlay */}
                  <div className="absolute bottom-2 right-2 w-12 h-12 bg-primary rounded-full flex items-center justify-center text-primary-foreground shadow-xl opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
                    <Play className="w-6 h-6 fill-current ml-1" />
                  </div>
                </div>
                <h3 className="font-bold text-white truncate mb-1">{playlist.name}</h3>
                <p className="text-sm text-muted-foreground line-clamp-2 min-h-[2.5rem]">
                  {playlist.description || `${playlist.trackCount} tracks`}
                </p>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
