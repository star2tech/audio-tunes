import React, { createContext, useContext, useState, useRef, useEffect, useCallback } from 'react';
import { Track } from '@workspace/api-client-react';

interface PlayerState {
  currentTrack: Track | null;
  queue: Track[];
  isPlaying: boolean;
  volume: number;
  progress: number;
  duration: number;
}

interface PlayerContextType extends PlayerState {
  playTrack: (track: Track, newQueue?: Track[]) => void;
  pause: () => void;
  resume: () => void;
  togglePlay: () => void;
  nextTrack: () => void;
  prevTrack: () => void;
  setVolumeLevel: (vol: number) => void;
  seekTo: (seconds: number) => void;
}

const PlayerContext = createContext<PlayerContextType | null>(null);

export function PlayerProvider({ children }: { children: React.ReactNode }) {
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [queue, setQueue] = useState<Track[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(50);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);

  const playerRef = useRef<any>(null);
  const progressInterval = useRef<number | null>(null);
  const pendingVideoIdRef = useRef<string | null>(null);
  // Stable ref to nextTrack so the YT onStateChange closure never goes stale
  const nextTrackRef = useRef<(() => void) | null>(null);

  // ── Timer helpers ──────────────────────────────────────────────────────────

  const startProgressTimer = useCallback(() => {
    if (progressInterval.current) window.clearInterval(progressInterval.current);
    progressInterval.current = window.setInterval(() => {
      if (playerRef.current && typeof playerRef.current.getCurrentTime === 'function') {
        setProgress(playerRef.current.getCurrentTime());
      }
    }, 1000);
  }, []);

  const stopProgressTimer = useCallback(() => {
    if (progressInterval.current) {
      window.clearInterval(progressInterval.current);
      progressInterval.current = null;
    }
  }, []);

  // ── Core player init ───────────────────────────────────────────────────────

  const initPlayer = useCallback((videoId: string) => {
    if (!videoId) return;

    // Player is fully ready — reuse it
    if (playerRef.current && typeof playerRef.current.loadVideoById === 'function') {
      playerRef.current.loadVideoById(videoId);
      setIsPlaying(true);
      startProgressTimer();
      return;
    }

    // Player ref is stale — destroy and recreate
    if (playerRef.current) {
      try { playerRef.current.destroy(); } catch {}
      playerRef.current = null;
    }

    // YouTube IFrame API hasn't loaded yet — queue and wait
    if (!(window as any).YT?.Player) {
      pendingVideoIdRef.current = videoId;
      return;
    }

    // Ensure hidden mount point exists
    let playerDiv = document.getElementById('yt-player-hidden');
    if (!playerDiv) {
      playerDiv = document.createElement('div');
      playerDiv.id = 'yt-player-hidden';
      Object.assign(playerDiv.style, {
        position: 'absolute', top: '-9999px', left: '-9999px',
      });
      document.body.appendChild(playerDiv);
    }

    playerRef.current = new (window as any).YT.Player('yt-player-hidden', {
      height: '0',
      width: '0',
      videoId,
      playerVars: { autoplay: 1, controls: 0, disablekb: 1, fs: 0, modestbranding: 1, playsinline: 1 },
      events: {
        onReady: (event: any) => {
          event.target.setVolume(volume);
          event.target.playVideo();
          setIsPlaying(true);
          startProgressTimer();
        },
        onStateChange: (event: any) => {
          const YTState = (window as any).YT?.PlayerState;
          if (!YTState) return;
          if (event.data === YTState.PLAYING) {
            setIsPlaying(true);
            setDuration(event.target.getDuration());
            startProgressTimer();
          } else if (event.data === YTState.PAUSED) {
            setIsPlaying(false);
            stopProgressTimer();
          } else if (event.data === YTState.ENDED) {
            setIsPlaying(false);
            stopProgressTimer();
            nextTrackRef.current?.();
          }
        },
      },
    });
  }, [volume, startProgressTimer, stopProgressTimer]);

  // ── Load YouTube IFrame API ────────────────────────────────────────────────

  useEffect(() => {
    if (!(window as any).YT) {
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      document.head.appendChild(tag);
    }

    // Called by YouTube when the API is ready
    (window as any).onYouTubeIframeAPIReady = () => {
      if (pendingVideoIdRef.current) {
        const vid = pendingVideoIdRef.current;
        pendingVideoIdRef.current = null;
        initPlayer(vid);
      }
    };

    return () => {
      if (progressInterval.current) window.clearInterval(progressInterval.current);
    };
  }, [initPlayer]);

  // ── Playback controls ──────────────────────────────────────────────────────

  const playTrack = useCallback((track: Track, newQueue?: Track[]) => {
    setCurrentTrack(track);
    if (newQueue) setQueue(newQueue);
    setProgress(0);
    setDuration(track.durationMs / 1000);
    if (track.youtubeVideoId) {
      initPlayer(track.youtubeVideoId);
    } else {
      setIsPlaying(false);
    }
  }, [initPlayer]);

  // When a track's youtubeVideoId arrives late (auto-search resolves), start playing
  useEffect(() => {
    if (
      currentTrack?.youtubeVideoId &&
      !isPlaying &&
      playerRef.current?.getVideoData?.()?.video_id !== currentTrack.youtubeVideoId
    ) {
      initPlayer(currentTrack.youtubeVideoId);
    }
  }, [currentTrack?.youtubeVideoId, isPlaying, initPlayer]);

  const pause = useCallback(() => {
    if (playerRef.current && typeof playerRef.current.pauseVideo === 'function') {
      playerRef.current.pauseVideo();
    }
    setIsPlaying(false);
  }, []);

  const resume = useCallback(() => {
    if (currentTrack && !currentTrack.youtubeVideoId) return;
    if (playerRef.current && typeof playerRef.current.playVideo === 'function') {
      playerRef.current.playVideo();
    }
    setIsPlaying(true);
  }, [currentTrack]);

  const togglePlay = useCallback(() => {
    if (isPlaying) pause();
    else resume();
  }, [isPlaying, pause, resume]);

  const seekTo = useCallback((seconds: number) => {
    if (playerRef.current && typeof playerRef.current.seekTo === 'function') {
      playerRef.current.seekTo(seconds, true);
      setProgress(seconds);
    }
  }, []);

  const nextTrack = useCallback(() => {
    if (!currentTrack || queue.length === 0) return;
    const idx = queue.findIndex(t => t.id === currentTrack.id);
    if (idx >= 0 && idx < queue.length - 1) {
      playTrack(queue[idx + 1]);
    } else {
      setIsPlaying(false);
      setProgress(0);
      if (playerRef.current && typeof playerRef.current.stopVideo === 'function') {
        playerRef.current.stopVideo();
      }
    }
  }, [currentTrack, queue, playTrack]);

  // Keep ref stable so the YT onStateChange closure always sees the latest nextTrack
  useEffect(() => { nextTrackRef.current = nextTrack; }, [nextTrack]);

  const prevTrack = useCallback(() => {
    if (!currentTrack || queue.length === 0) return;
    if (progress > 3) { seekTo(0); return; }
    const idx = queue.findIndex(t => t.id === currentTrack.id);
    if (idx > 0) playTrack(queue[idx - 1]);
  }, [currentTrack, queue, playTrack, progress, seekTo]);

  const setVolumeLevel = useCallback((vol: number) => {
    setVolume(vol);
    if (playerRef.current && typeof playerRef.current.setVolume === 'function') {
      playerRef.current.setVolume(vol);
    }
  }, []);

  return (
    <PlayerContext.Provider
      value={{
        currentTrack, queue, isPlaying, volume, progress, duration,
        playTrack, pause, resume, togglePlay, nextTrack, prevTrack,
        setVolumeLevel, seekTo,
      }}
    >
      {children}
    </PlayerContext.Provider>
  );
}

export function usePlayer() {
  const context = useContext(PlayerContext);
  if (!context) throw new Error('usePlayer must be used within a PlayerProvider');
  return context;
}
